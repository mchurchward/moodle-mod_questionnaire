// (C) Copyright 2017 Mike Churchward <mike.churchward@poetgroup.org>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.mod_questionnaire')

/**
 * Mod questionnaire prefetch handler.
 *
 * @module mm.addons.mod_questionnaire
 * @ngdoc service
 * @name $mmaModQuestionnairePrefetchHandler
 */
.factory('$mmaModQuestionnairePrefetchHandler', function($mmaModQuestionnaire, mmaModQuestionnaireComponent, $mmFilepool, $q, $mmUtil, $mmGroups,
            $mmPrefetchFactory) {

    var self = $mmPrefetchFactory.createPrefetchHandler(mmaModQuestionnaireComponent);

    // RegExp to check if a module has updates based on the result of $mmCoursePrefetchDelegate#getCourseUpdates.
    // check_updates_since not available yet on module lib.
    // self.updatesNames = /^configuration$|^.*files$|^answers$/;

    /**
     * Download the module.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#download
     * @param  {Object} module   The module object returned by WS.
     * @param  {Number} courseId Course ID the module belongs to.
     * @return {Promise}         Promise resolved when all files have been downloaded. Data returned is not reliable.
     */
    self.download = function(module, courseId) {
        // Questionnaire cannot be downloaded right away, only prefetched.
        return self.prefetch(module, courseId);
    };

    /**
     * Get the list of downloadable files.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#getFiles
     * @param  {Object} module    Module to get the files.
     * @param  {Number} courseId  Course ID the module belongs to.
     * @param  {String} [siteId]  Site ID. If not defined, current site.
     * @return {Promise}          Promise resolved with the list of files.
     */
    self.getFiles = function(module, courseId, siteId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, siteId).then(function(questionnaire) {
            // Get intro files and page after submit files.
            var files = questionnaire.pageaftersubmitfiles || [];
            return files.concat(self.getIntroFilesFromInstance(module, questionnaire));
        }).catch(function() {
            // Questionnaire not found, return empty list.
            return [];
        });
    };

    /**
     * Returns questionnaire intro files.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#getIntroFiles
     * @param  {Object} module   The module object returned by WS.
     * @param  {Number} courseId Course ID.
     * @return {Promise}         Promise resolved with list of intro files.
     */
    self.getIntroFiles = function(module, courseId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id).catch(function() {
            // Not found, return undefined so module description is used.
        }).then(function(questionnaire) {
            return self.getIntroFilesFromInstance(module, questionnaire);
        });
    };

    /**
     * Invalidate the prefetched content.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#invalidateContent
     * @param  {Number} moduleId The module ID.
     * @param  {Number} courseId Course ID of the module.
     * @return {Promise}
     */
    self.invalidateContent = function(moduleId, courseId) {
        return $mmaModQuestionnaire.invalidateContent(moduleId, courseId);
    };

    /**
     * Invalidates WS calls needed to determine module status.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#invalidateModule
     * @param  {Object} module   Module to invalidate.
     * @param  {Number} courseId Course ID the module belongs to.
     * @return {Promise}         Promise resolved when done.
     */
    self.invalidateModule = function(module, courseId) {
        return $mmaModQuestionnaire.invalidateQuestionnaireData(courseId);
    };

    /**
     * Check if a questionnaire is downloadable.
     * A questionnaire isn't downloadable if it's not open yet.
     * Closed questionnaire are downloadable because teachers can always see the results.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#isDownloadable
     * @param {Object} module    Module to check.
     * @param {Number} courseId  Course ID the module belongs to.
     * @return {Promise}         Promise resolved with true if downloadable, resolved with false otherwise.
     */
    self.isDownloadable = function(module, courseId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, false, true).then(function(questionnaire) {
            var now = $mmUtil.timestamp();

            // Check time first if available.
            if (questionnaire.timeopen && questionnaire.timeopen > now) {
                return false;
            }
            if (questionnaire.timeclose && questionnaire.timeclose < now) {
                return false;
            }
            return $mmaModQuestionnaire.getQuestionnaireAccessInformation(questionnaire.id).then(function(accessData) {
                return accessData.isopen;
            });
        });
    };

    /**
     * Whether or not the module is enabled for the site.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#isEnabled
     * @return {Boolean}
     */
    self.isEnabled = function() {
        return $mmaModQuestionnaire.isPluginEnabled();
    };

    /**
     * Prefetch the module.
     *
     * @module mm.addons.mod_questionnaire
     * @ngdoc method
     * @name $mmaModQuestionnairePrefetchHandler#prefetch
     * @param  {Object} module   The module object returned by WS.
     * @param  {Number} courseId Course ID the module belongs to.
     * @param  {Boolean} single  True if we're downloading a single module, false if we're downloading a whole section.
     * @return {Promise}         Promise resolved when all files have been downloaded. Data returned is not reliable.
     */
    self.prefetch = function(module, courseId, single) {
        return self.prefetchPackage(module, courseId, single, prefetchQuestionnaire);
    };

    /**
     * Prefetch a questionnaire.
     *
     * @param  {Object} module   The module object returned by WS.
     * @param  {Number} courseId Course ID the module belongs to.
     * @param  {Boolean} single  True if we're downloading a single module, false if we're downloading a whole section.
     * @param  {String} siteId   Site ID.
     * @return {Promise}         Promise resolved with an object with 'revision' and 'timemod'.
     */
    function prefetchQuestionnaire(module, courseId, single, siteId) {
        // Prefetch the questionnaire data.
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, siteId).then(function(questionnaire) {
            var p1 = [];

            p1.push(self.getFiles(module, courseId, siteId).then(function(files) {
                return $mmFilepool.addFilesToQueueByUrl(siteId, files, self.component, module.id);
            }));

            p1.push($mmaModQuestionnaire.getQuestionnaireAccessInformation(questionnaire.id, siteId).then(function(accessData) {
                var p2 = [];
                if (accessData.capabilities && accessData.capabilities.edititems) {
                    // Get all groups analysis.
                    p2.push($mmaModQuestionnaire.getAnalysis(questionnaire.id, undefined, siteId));
                    p2.push($mmGroups.getActivityAllowedGroupsIfEnabled(questionnaire.coursemodule, undefined, siteId).then(function(groups) {
                        var p3 = [];
                        angular.forEach(groups, function(group) {
                            p3.push($mmaModQuestionnaire.getAnalysis(questionnaire.id, group.id, siteId));
                        });

                        return $q.all(p3);
                    }));
                }

                return $q.all(p2);
            }));

            return $q.all(p1);
        }).then(function() {
            // Get revision and timemodified.

            var p4 = [];
            p4.push(self.getRevision(module, courseId));
            p4.push(self.getTimemodified(module, courseId));

            // Return revision and timemodified.
            return $q.all(p4).then(function(list) {
                return {
                    revision: list[0],
                    timemod: list[1]
                };
            });
        });
    }

    return self;
});