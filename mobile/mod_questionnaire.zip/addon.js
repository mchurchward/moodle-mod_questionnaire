angular.module('mm.addons.mod_questionnaire', [])
.constant('mmaModQuestionnaireComponent', 'mmaModQuestionnaire')
.config(["$stateProvider", function($stateProvider) {
    $stateProvider
    .state('site.mod_questionnaire', {
        url: '/mod_questionnaire',
        params: {
            module: null,
            moduleid: null,
            courseid: null
        },
        views: {
            'site': {
                controller: 'mmaModQuestionnaireIndexCtrl',
                templateUrl: '$ADDONPATH$/templates/index.html'
            }
        }
    });
}])
.config(["$mmCourseDelegateProvider", "$mmContentLinksDelegateProvider", "$mmCoursePrefetchDelegateProvider", function($mmCourseDelegateProvider, $mmContentLinksDelegateProvider, $mmCoursePrefetchDelegateProvider) {
    $mmCourseDelegateProvider.registerContentHandler('mmaModQuestionnaire', 'questionnaire', '$mmaModQuestionnaireHandlers.courseContent');
    $mmContentLinksDelegateProvider.registerLinkHandler('mmaModQuestionnaire:index', '$mmaModQuestionnaireHandlers.indexLinksHandler');
    $mmCoursePrefetchDelegateProvider.registerPrefetchHandler('mmaModQuestionnaire', 'questionnaire', '$mmaModQuestionnairePrefetchHandler');
}]);
angular.module('mm.addons.mod_questionnaire')
.factory('$mmaModQuestionnaireHandlers', ["$mmCourse", "$mmaModQuestionnaire", "$state", "$mmContentLinksHelper", "$mmUtil", "$mmEvents", "$mmSite", "mmaModQuestionnaireComponent", "$mmaModQuestionnairePrefetchHandler", "mmCoreDownloading", "mmCoreNotDownloaded", "mmCoreEventPackageStatusChanged", "mmCoreOutdated", "$mmCoursePrefetchDelegate", function($mmCourse, $mmaModQuestionnaire, $state, $mmContentLinksHelper, $mmUtil, $mmEvents, $mmSite,
        mmaModQuestionnaireComponent, $mmaModQuestionnairePrefetchHandler, mmCoreDownloading, mmCoreNotDownloaded,
        mmCoreEventPackageStatusChanged, mmCoreOutdated, $mmCoursePrefetchDelegate) {
    var self = {};
        self.courseContent = function() {
        var self = {};
                self.isEnabled = function() {
            return $mmaModQuestionnaire.isPluginEnabled();
        };
                self.getController = function(module, courseId) {
            return function($scope) {
                var downloadBtn = {
                        hidden: true,
                        icon: 'ion-ios-cloud-download-outline',
                        label: 'mm.core.download',
                        action: function(e) {
                            if (e) {
                                e.preventDefault();
                                e.stopPropagation();
                            }
                            download();
                        }
                    },
                    refreshBtn = {
                        hidden: true,
                        icon: 'ion-android-refresh',
                        label: 'mm.core.refresh',
                        action: function(e) {
                            if (e) {
                                e.preventDefault();
                                e.stopPropagation();
                            }
                            $mmaModQuestionnaire.invalidateContent(module.id, courseId).finally(function() {
                                download();
                            });
                        }
                    };
                $scope.title = module.name;
                $scope.icon = $mmCourse.getModuleIconSrc('questionnaire');
                $scope.class = 'mma-mod_questionnaire-handler';
                $scope.buttons = [downloadBtn, refreshBtn];
                $scope.spinner = true;
                $scope.action = function(e) {
                    if (e) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    $state.go('site.mod_questionnaire', {module: module, moduleid: module.id, courseid: courseId});
                };
                function download() {
                    $scope.spinner = true;
                    $mmaModQuestionnairePrefetchHandler.getDownloadSize(module, courseId).then(function(size) {
                        $mmUtil.confirmDownloadSize(size).then(function() {
                            $mmaModQuestionnairePrefetchHandler.prefetch(module, courseId).catch(function() {
                                if (!$scope.$$destroyed) {
                                    $mmUtil.showErrorModal('mm.core.errordownloading', true);
                                }
                            });
                        }).catch(function() {
                            $scope.spinner = false;
                        });
                    }).catch(function(error) {
                        $scope.spinner = false;
                        $mmUtil.showErrorModalDefault(error, 'mm.core.errordownloading', true);
                    });
                }
                function showStatus(status) {
                    if (status) {
                        $scope.spinner = status === mmCoreDownloading;
                        downloadBtn.hidden = status !== mmCoreNotDownloaded;
                        refreshBtn.hidden = status !== mmCoreOutdated;
                    }
                }
                var statusObserver = $mmEvents.on(mmCoreEventPackageStatusChanged, function(data) {
                    if (data.siteid === $mmSite.getId() && data.componentId === module.id &&
                            data.component === mmaModQuestionnaireComponent) {
                        showStatus(data.status);
                    }
                });
                $mmCoursePrefetchDelegate.getModuleStatus(module, courseId).then(showStatus);
                $scope.$on('$destroy', function() {
                    statusObserver && statusObserver.off && statusObserver.off();
                });
            };
        };
        return self;
    };
        self.indexLinksHandler = $mmContentLinksHelper.createModuleIndexLinkHandler('mmaModQuestionnaire', 'questionnaire', $mmaModQuestionnaire);
    return self;
}]);
angular.module('mm.addons.mod_questionnaire')
.factory('$mmaModQuestionnairePrefetchHandler', ["$mmaModQuestionnaire", "mmaModQuestionnaireComponent", "$mmFilepool", "$q", "$mmUtil", "$mmGroups", "$mmPrefetchFactory", function($mmaModQuestionnaire, mmaModQuestionnaireComponent, $mmFilepool, $q, $mmUtil, $mmGroups,
            $mmPrefetchFactory) {
    var self = $mmPrefetchFactory.createPrefetchHandler(mmaModQuestionnaireComponent);
        self.download = function(module, courseId) {
        return self.prefetch(module, courseId);
    };
        self.getFiles = function(module, courseId, siteId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, siteId).then(function(questionnaire) {
            var files = questionnaire.pageaftersubmitfiles || [];
            return files.concat(self.getIntroFilesFromInstance(module, questionnaire));
        }).catch(function() {
            return [];
        });
    };
        self.getIntroFiles = function(module, courseId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id).catch(function() {
        }).then(function(questionnaire) {
            return self.getIntroFilesFromInstance(module, questionnaire);
        });
    };
        self.invalidateContent = function(moduleId, courseId) {
        return $mmaModQuestionnaire.invalidateContent(moduleId, courseId);
    };
        self.invalidateModule = function(module, courseId) {
        return $mmaModQuestionnaire.invalidateQuestionnaireData(courseId);
    };
        self.isDownloadable = function(module, courseId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, false, true).then(function(questionnaire) {
            var now = $mmUtil.timestamp();
            if (questionnaire.timeopen && questionnaire.timeopen > now) {
                return false;
            }
            if (questionnaire.timeclose && questionnaire.timeclose < now) {
                return false;
            }
            return $mmaModQuestionnaire.getQuestionnaireAccessInformation(questionnaire.id).then(function(accessData) {
                return accessData.isopen;
            });
        });
    };
        self.isEnabled = function() {
        return $mmaModQuestionnaire.isPluginEnabled();
    };
        self.prefetch = function(module, courseId, single) {
        return self.prefetchPackage(module, courseId, single, prefetchQuestionnaire);
    };
        function prefetchQuestionnaire(module, courseId, single, siteId) {
        return $mmaModQuestionnaire.getQuestionnaire(courseId, module.id, siteId).then(function(questionnaire) {
            var p1 = [];
            p1.push(self.getFiles(module, courseId, siteId).then(function(files) {
                return $mmFilepool.addFilesToQueueByUrl(siteId, files, self.component, module.id);
            }));
            p1.push($mmaModQuestionnaire.getQuestionnaireAccessInformation(questionnaire.id, siteId).then(function(accessData) {
                var p2 = [];
                if (accessData.capabilities && accessData.capabilities.edititems) {
                    p2.push($mmaModQuestionnaire.getAnalysis(questionnaire.id, undefined, siteId));
                    p2.push($mmGroups.getActivityAllowedGroupsIfEnabled(questionnaire.coursemodule, undefined, siteId).then(function(groups) {
                        var p3 = [];
                        angular.forEach(groups, function(group) {
                            p3.push($mmaModQuestionnaire.getAnalysis(questionnaire.id, group.id, siteId));
                        });
                        return $q.all(p3);
                    }));
                }
                return $q.all(p2);
            }));
            return $q.all(p1);
        }).then(function() {
            var p4 = [];
            p4.push(self.getRevision(module, courseId));
            p4.push(self.getTimemodified(module, courseId));
            return $q.all(p4).then(function(list) {
                return {
                    revision: list[0],
                    timemod: list[1]
                };
            });
        });
    }
    return self;
}]);
angular.module('mm.addons.mod_questionnaire')
.factory('$mmaModQuestionnaire', ["$q", "$mmSite", "$mmSitesManager", "$mmFilepool", "mmaModQuestionnaireComponent", "$mmUtil", function($q, $mmSite, $mmSitesManager, $mmFilepool, mmaModQuestionnaireComponent, $mmUtil) {
    var self = {};
        function getQuestionnaireDataCacheKey(courseId) {
        return 'mmaModQuestionnaire:questionnaire:' + courseId;
    }
        function getQuestionnaireAccessInformationDataCacheKey(questionnaireId) {
        return 'mmaModQuestionnaire:access:' + questionnaireId;
    }
        function getAnalysisDataPrefixCacheKey(questionnaireId) {
        return 'mmaModQuestionnaire:analysis:' + questionnaireId;
    }
        function getAnalysisDataCacheKey(questionnaireId, groupId) {
        groupId = groupId || 0;
        return getAnalysisDataPrefixCacheKey(questionnaireId) + ":" + groupId;
    }
        self.isPluginEnabled = function(siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return  site.wsAvailable('mod_questionnaire_get_questionnaires_by_courses') &&
                    site.wsAvailable('mod_questionnaire_get_access_information');
        });
    };
        function getQuestionnaire(courseId, key, value, siteId, forceCache) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                    courseids: [courseId]
                },
                preSets = {
                    cacheKey: getQuestionnaireDataCacheKey(courseId)
                };
            if (forceCache) {
                preSets.omitExpires = true;
            }
            return site.read('mod_questionnaire_get_questionnaires_by_courses', params, preSets).then(function(response) {
                if (response && response.questionnaires) {
                    var current;
                    angular.forEach(response.questionnaires, function(questionnaire) {
                        if (!current && questionnaire[key] == value) {
                            current = questionnaire;
                        }
                    });
                    if (current) {
                        return current;
                    }
                }
                return $q.reject();
            });
        });
    }
        self.getQuestionnaire = function(courseId, cmId, siteId, forceCache) {
        return getQuestionnaire(courseId, 'coursemodule', cmId, siteId, forceCache);
    };
        self.getQuestionnaireById = function(courseId, id, siteId, forceCache) {
        return getQuestionnaire(courseId, 'id', id, siteId, forceCache);
    };
        self.invalidateQuestionnaireData = function(courseId, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKey(getQuestionnaireDataCacheKey(courseId));
        });
    };
        self.getQuestionnaireAccessInformation = function(questionnaireId, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                    questionnaireid: questionnaireId
                },
                preSets = {
                    cacheKey: getQuestionnaireAccessInformationDataCacheKey(questionnaireId)
                };
            return site.read('mod_questionnaire_get_access_information', params, preSets).then(function(accessData) {
                accessData.capabilities = $mmUtil.objectToKeyValueMap(accessData.capabilities, 'name', 'enabled', 'mod/questionnaire:');
                return accessData;
            });
        });
    };
        self.invalidateQuestionnaireAccessInformationData = function(questionnaireId, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKey(getQuestionnaireAccessInformationDataCacheKey(questionnaireId));
        });
    };
        self.getAnalysis = function(questionnaireId, groupId, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                    questionnaireid: questionnaireId
                },
                preSets = {
                    cacheKey: getAnalysisDataCacheKey(questionnaireId, groupId)
                };
            if (groupId) {
                params.groupid = groupId;
            }
            return site.read('mod_questionnaire_get_analysis', params, preSets);
        });
    };
        self.invalidateAnalysisData = function(questionnaireId, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKeyStartingWith(getAnalysisDataPrefixCacheKey(questionnaireId));
        });
    };
        self.invalidateContent = function(moduleId, courseId, siteId) {
        siteId = siteId || $mmSite.getId();
        return self.getQuestionnaire(courseId, moduleId, siteId, true).then(function(questionnaire) {
            var ps = [];
            ps.push(self.invalidateQuestionnaireData(courseId, siteId));
            ps.push(self.invalidateQuestionnaireAccessInformationData(questionnaire.id, siteId));
            ps.push(self.invalidateAnalysisData(questionnaire.id, siteId));
            return $q.all(ps);
        });
    };
        self.invalidateFiles = function(moduleId, siteId) {
        return $mmFilepool.invalidateFilesByComponent(siteId, mmaModQuestionnaireComponent, moduleId);
    };
        self.logView = function(id, siteId) {
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                questionnaireid: id
            };
            return site.write('mod_questionnaire_view_questionnaire', params);
        });
    };
    return self;
}]);